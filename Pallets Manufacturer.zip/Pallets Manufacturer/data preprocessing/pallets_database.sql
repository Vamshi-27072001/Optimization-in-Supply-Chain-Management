select * from pallets;

SELECT COUNT(*) from pallets;

#mean
select AVG(qty) as mean_Qty from pallets;
#meadian
select qty as median_QTY
from(
select QTY,
row_number() over(order by QTY)  as row_num,
count(*) over() as total_count
from pallets
)as subquery 
 where row_num = (total_count +1)/2 or row_num = (total_count +2)/2;
select qty as mode_QTY
from pallets
group by qty
having count(qty) = (
select max(qtycount)
from(
select qty, count(qty) as qtycount
from pallets
group by qty 
)as subquery
);
select stddev(qty) as qty_stddev from pallets;
select max(qty) - min(qty) as
qty_ramge
 from pallets;
 select variance(qty)  as
 qty_variance
 from pallets;
 # Third moment of business decision
 
 #skewness
 
 select
 (
 sum(power(qty-(select avg(qty) from pallets),3))/
 (count(*)*power((select stddev(qty) from pallets),3))
 ) as skewness
 from pallets;
 
 # four momentof business decision
 
 # kurtosis
 
 select
 (
 (sum(power(qty-(select avg(qty) from pallets),4))/
 (count(*)* power((select stddev(qty) from pallets),4))) - 3
 ) as kurtosis
 from pallets;

#checking null values/missing values:
SELECT count(*) FROM pallets where qty is Null;


#Range
SELECT MAX(qty)- MIN(qty) as range, AVG(qty) FROM pallets;



-- Calculate the mean and standard deviation of the column
SELECT AVG(qty), stddev(qty)
FROM pallets;

SELECT count(*) FROM pallets where WHName is Null;

#Data type
SELECT DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = 'pallets' AND COLUMN_NAME = 'custname';
SELECT DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = 'pallets' AND COLUMN_NAME = 'qty';
SELECT DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = 'pallets' AND COLUMN_NAME = 'WHName';


# Outliers in qTy_cloumn.
SELECT
    AVG(qty) AS mean,
    PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY qty) AS q1,
    PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY qty) AS q3,
    MAX(qty) AS max_value,
    MIN(qty) AS min_value,
    STDDEV(qty) AS std_dev
FROM pallets;

















