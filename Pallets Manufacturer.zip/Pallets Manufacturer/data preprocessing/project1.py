import psycopg2

# Database connection parameters
db_params = {
    'database': 'Project of Pallets',
    'user': 'postgres',
    'password': 'vamshi',
    'host': 'localhost',
    'port': '5432',
}

# Establish a connection to the database
connection = psycopg2.connect(**db_params)

# Create a cursor object to execute SQL queries
cursor = connection.cursor()

# Execute SQL queries
cursor.execute("SELECT * FROM pallets")
rows = cursor.fetchall()

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from feature_engine.outliers import Winsorizer
from sklearn.preprocessing import OneHotEncoder
from feature_engine.imputation import RandomSampleImputer
import scipy.stats as stats
import pylab
from sklearn.preprocessing import StandardScaler
from feature_engine import transformation

df = pd.read_excel(r"C:\Users\91863\Desktop\Projects\pallet_Masked_fulldata.xlsx")

df.shape 

df.info()

df.describe()

df.QTY.mean()
df.QTY.median()
df.QTY.mode()


df.QTY.std()
df.QTY.var()
range = max(df.QTY)- min(df.QTY)
range

df.QTY.skew()
df.QTY.kurt()

df.isnull().sum()

# Data visualisation

plt.bar(x=range(80962), height=df.QTY)

plt.hist(df.QTY)

plt.boxplot(df.QTY, vert=0)

#Deprecated histogram functon from seaborn, Distrubution plot
sns.displot(df.QTY) # Histogram from seaborn

# Density plot
sns.kdeplot(df.QTY, bw = 1, fill = True)

# AutoEDA Sweetviz
import sweetviz
report = sweetviz.analyze(df)
report.show_html('report_html')

#AutoEDA Autoviz
from autoviz import AutoViz_Class
AV = AutoViz_Class()
dft = AV.AutoViz(r'C:\Users\91863\Desktop\Projects\pallet_Masked_fulldata.xlsx')


#####tpye casting####
df.CustName = df.CustName.astype('str')
df.dtypes

df.WHName = df.WHName.astype('str')
df.dtypes

#Creating duplicate of Data frame before treating outliers
df1 = df.copy()
#Deleting negtive values
df = df.drop(df.index[df['QTY']< 0])

plt.boxplot(df.QTY, vert=0)

############## Outlier Treatment ###############

# Let's find outliers in QTY
sns.boxplot(df.QTY)

# Detection of outliers (find limits for QTY based on IQR)
IQR = df['QTY'].quantile(0.75) - df['QTY'].quantile(0.25)

lower_limit = df['QTY'].quantile(0.25) - (IQR * 1.5)
upper_limit = df['QTY'].quantile(0.75) + (IQR * 1.5)

############### 1. Remove (let's trim the dataset) ################
# Trimming Technique
# Let's flag the outliers in the dataset
outliers_df = np.where(df.QTY > upper_limit, True, False)
df_trimmed = df.loc[~(outliers_df), ]
df.shape, df_trimmed.shape

# Let's explore outliers in the trimmed dataset
sns.boxplot(df_trimmed.QTY)
############### 2. Replace ###############
# Replace the outliers by the maximum and minimum limit
df['df_replaced'] = pd.DataFrame(np.where(df['QTY'] > upper_limit, upper_limit, df['QTY']))
sns.boxplot(df.df_replaced)

############### 3. Winsorization ###############
# pip install feature_engine   # install the package

# Define the model with IQR method
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                        # choose  IQR rule boundaries or gaussian for mean and std
                          tail = 'right', # cap left, right or both tails 
                          fold = 1.5,
                          variables = ['QTY'])

df_s = winsor_iqr.fit_transform(df[['QTY']])

# Inspect the minimum caps and maximum caps
# winsor.left_tail_caps_, winsor.right_tail_caps_

# Let's see boxplot
sns.boxplot(df_s.QTY)


# Define the model with Gaussian method
winsor_gaussian = Winsorizer(capping_method = 'gaussian', 
                             # choose IQR rule boundaries or gaussian for mean and std
                          tail = 'right', # cap left, right or both tails 
                          fold = 3,
                          variables = ['QTY'])

df_t = winsor_gaussian.fit_transform(df[['QTY']])
sns.boxplot(df_t.QTY)
# Define the model with percentiles:
# Default values
# Right tail: 95th percentile
# Left tail: 5th percentile

winsor_percentile = Winsorizer(capping_method = 'quantiles',
                          tail = 'right', # cap left, right or both tails 
                          fold = 0.05, # limits will be the 5th and 95th percentiles
                          variables = ['QTY'])

df_p = winsor_percentile.fit_transform(df[['QTY']])
sns.boxplot(df_p.QTY)


#### zero variance and near zero variance ####

# If the variance is low or close to zero, then a feature is approximately constant and will not improve the performance of the model.
# In that case, it should be removed. 
df.QTY.var() # variance of numeric variables
df.QTY.var() == 0
df.QTY.var(axis = 0) == 0

#############
# Discretization
df.head(10)

# Binarization
df['QTY_new'] = pd.cut(df['QTY'],
                       bins = [min(df.QTY), df.QTY.mean(), max(df.QTY)], 
                       labels = ['Low','High'])

df.QTY_new.value_counts()# Look out for the break up of the categories.

df['QTY_new1'] = pd.cut(df['QTY'],
                       bins = [min(df.QTY), df.QTY.mean(), max(df.QTY)],
                       include_lowest= True,
                       labels = ['Low','High'])

df.QTY_new1.value_counts()

df.info()

## Discretization / Multiple bins
df['QTY_multi'] = pd.cut(df['QTY'], 
                        bins = [min(df.QTY), df.QTY.quantile(0.25), df.QTY.mean(),  df.QTY.quantile(0.75), max(df.QTY)], 
                              include_lowest = True,
                              labels = ["A1", "B2", "C3", "D4"])
df.QTY_multi.value_counts()
#### Dummy Variables ###############
df.columns
df.shape

#Drop 
df.drop(['CustName','WHName','Unnamed: 0'], axis=1, inplace=True)

#Create dummy variables
df_dummy = pd.get_dummies(df)

# Created dummies for all categorical columns
df_dummy_1 = pd.get_dummies(df, drop_first=True)

######One Hot Encoding########
df.columns
df = df[['QTY','Date', 'City', 'Region', 'State', 'Product Code', 'Transaction Type','df_replaced', 'QTY_new', 'QTY_new1', 'QTY_multi']]

# Creating instance of One-Hot Encoder
pallet = OneHotEncoder()

pallet_df = pd.DataFrame(pallet.fit_transform(df.iloc[:,2:]).toarray())
duplicate = df.duplicated()  # Returns Boolean Series denoting duplicate rows.
duplicate

sum(duplicate)

df = df.drop_duplicates()
duplicate = df.duplicated()  # Returns Boolean Series denoting duplicate rows.
duplicate
sum(duplicate)

#################### Missing Values - Imputation ###########################

# Check for count of NA's in each column
df.isna().sum()
random_imputer = RandomSampleImputer(['df_replaced'])
df["df_replaced"] = pd.DataFrame(random_imputer.fit_transform(df[["df_replaced"]]))
df["df_replaced"].isna().sum()

random_imputer = RandomSampleImputer(['QTY_new'])
df["QTY_new"] = pd.DataFrame(random_imputer.fit_transform(df[["QTY_new"]]))
df["QTY_new"].isna().sum()  # a
df.isna().sum()

#####################
# Normal Quantile-Quantile Plot

# Checking whether data is normally distributed
stats.probplot(df.QTY, dist = "norm", plot = pylab)

# Yeo-Johnson Transform

'''
We can apply it to our dataset without scaling the data.
It supports zero values and negative values. It does not require the values for 
each input variable to be strictly positive.'''
 
prob = stats.probplot(df.QTY, dist = stats.norm, plot = pylab)
# Set up the variable transformer
tf = transformation.YeoJohnsonTransformer(variables = 'QTY')
edu_tf = tf.fit_transform(df)
    
# Transformed data
prob = stats.probplot(edu_tf.QTY, dist = stats.norm, plot = pylab)


####################################################
######## Standardization and Normalization #########

### Standardization
# Initialise the Scaler
scaler = StandardScaler()

data = scaler.fit_transform(df[['QTY']])
# Convert the array back to a dataframe
dataset = pd.DataFrame(data)
res = dataset.describe()

### Normalization
## load dataset
### Normalization function - Custom Function
# Range converts to: 0 to 1
def norm_func(i):
    x = (i-i.min())/(i.max()-i.min())
    return(x)

df_norm = norm_func(df.QTY)
b = df_norm.describe()

df.QTY.mean()
df.df_replaced.mean()
df.QTY.median()
df.QTY.mode()


df.QTY.std()
df.QTY.var()
range = max(df.QTY)- min(df.QTY)
range

df.QTY.skew()
df.QTY.kurt()


# Close the cursor and the connection when done
cursor.close()
connection.close()













