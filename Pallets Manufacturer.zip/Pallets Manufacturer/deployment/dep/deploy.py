import pandas as pd
import numpy as np
import streamlit as st
import pickle
from datetime import datetime, timedelta

# Load the XGBoost model
model_filename = 'xgboost_model.pkl'
with open(model_filename, 'rb') as model_file:
    loaded_model = pickle.load(model_file)

# Function to make forecasts using the XGBoost model
def make_forecasts(days):
    dfff = pd.read_excel(r"C:\Users\91863\Desktop\Projects\pallet_Masked_fulldata.xlsx")
    dfff['Date'] = pd.to_datetime(dfff['Date'])
    dfff.set_index('Date', inplace=True)

    last_date = dfff.index[-1]
    forecast_dates = pd.date_range(start=last_date + pd.DateOffset(days=1), periods=days, freq='D')

    forecast_dfff = pd.DataFrame(index=forecast_dates)

    X_forecast = np.arange(len(dfff), len(dfff) + days).reshape(-1, 1)
    forecast_values = loaded_model.predict(X_forecast)

    forecast_dfff['QTY'] = forecast_values

    return forecast_dfff

# Streamlit App
st.title('Pallet Forecasting App')

# Automatically generate a 60-day forecast
forecast_data = make_forecasts(60)
st.subheader('60-Day Forecast:')
st.write(forecast_data)

# import numpy as np
from statsmodels.regression.linear_model import OLSResults
model = OLSResults.load('xgboost_model.pkl')
user = 'postgers'  # user name
password = 'vamshi'  # password
db = 'Project of Pallets'  # database name

def main():
    

    st.title("Forecasting")
    st.sidebar.title("Forecasting")

    # st.radio('Type of Cab you want to Book', options=['Mini', 'Sedan', 'XL', 'Premium', 'Rental'])
    html_temp = """
    <div style="background-color:tomato;padding:10px">
    <h2 style="color:white;text-align:center;">Forecasting </h2>
    </div>
    
    """
    st.markdown(html_temp, unsafe_allow_html = True)
    st.text("")
    

    uploadedFile = st.sidebar.file_uploader(r"C:\Users\91863\Desktop\Projects\pallet_Masked_fulldata.xlsx" ,type=['csv','xlsx'],accept_multiple_files=False,key="fileUploader")
    if uploadedFile is not None :
        try:

            data=pd.read_csv(r"C:\Users\91863\Desktop\pallet_Masked_fulldata.csv",  index_col=0)
        except:
                try:
                    data = pd.read_excel(r"C:\Users\91863\Desktop\Projects\pallet_Masked_fulldata.xlsx" ,  index_col=0)
                except:      
                    data = pd.DataFrame(r"C:\Users\91863\Desktop\Projects\pallet_Masked_fulldata.xlsx" )
                
    else:
        st.sidebar.warning(r"C:\Users\91863\Desktop\Projects\pallet_Masked_fulldata.xlsx")
    
    
    html_temp = """
    <div style="background-color:tomato;padding:10px">
    <p style="color:white;text-align:center;">Add DataBase Credientials </p>
    </div>
    """
    st.sidebar.markdown(html_temp, unsafe_allow_html = True)
            
    user = st.sidebar.text_input("user", "postger")
    pw = st.sidebar.text_input("password", "vamshi")
    db = st.sidebar.text_input("database", "Project of Pallets")
    
    
    if st.button("Predict"):
        connection = psycopg2.connect(**db_params)
        
        
        ###############################################
        st.subheader(":red[Forecast for Test data]", anchor=None)
         
        forecast_test = pd.DataFrame(model.predict(start = data.index[0], end = data.index[-1]))
        results = pd.concat([data,forecast_test], axis=1)
        
        import seaborn as sns
        cm = sns.light_palette("blue", as_cmap=True)
        st.table(results.style.background_gradient(cmap=cm).set_precision(2))
        
        ###############################################
        st.text("")
        st.subheader(":red[plot forecasts against actual outcomes]", anchor=None)
        #plot forecasts against actual outcomes
        fig, ax = plt.subplots()
        ax.plot(data.Footfalls)
        ax.plot(forecast_test, color = 'red')
        st.pyplot(fig)
        
        ###############################################
        st.text("")
        st.subheader(":red[Forecast for the nest 12 months]", anchor=None)
        
        forecast = pd.DataFrame(model.predict(start=data.index[-1] + 1, end=data.index[-1] + 12))
        st.table(forecast.style.background_gradient(cmap=cm).set_precision(2))
        
        # data.to_sql('forecast_pred', con = engine, if_exists = 'replace', chunksize = 1000, index = False)
        # #st.dataframe(result) or
        # #st.table(result.style.set_properties(**{'background-color': 'white','color': 'black'}))
                           
        # import seaborn as sns
        # cm = sns.light_palette("blue", as_cmap=True)
        # st.table(result.style.background_gradient(cmap=cm).set_precision(2))
        
        
if __name__ == "__main__":
    main()


